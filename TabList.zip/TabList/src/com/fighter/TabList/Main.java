package com.fighter.TabList;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.bukkit.Bukkit;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import com.fighter.TabList.API.API;
import com.fighter.TabList.API.TabList;
import com.fighter.TabList.Commands.Commands;
import com.fighter.TabList.Listeners.Animations;
import com.fighter.TabList.Listeners.TabListListeners;

public class Main extends JavaPlugin implements Listener{

	PluginManager pm = Bukkit.getServer().getPluginManager();
	
	public File pchFile = new File(getDataFolder(), "animations.yml");
	public YamlConfiguration pchConfig = YamlConfiguration.loadConfiguration(pchFile);
	
	public File pchFile2 = new File(getDataFolder(), "placeholders.yml");
	public YamlConfiguration getPlaceholders = YamlConfiguration.loadConfiguration(pchFile2);
	
	public void onEnable() {
		
		Reg();
		for(Player player:Bukkit.getOnlinePlayers()) {
		
			TabListListeners.tablistStart(player);
		
		}
		this.getConfig().options().copyDefaults(true);
		saveDefaultConfig();
		API.papi(this);
		regCMD();
		placeholders();
		//configAPI();
		API.setupEconomy();
		API.setupChat();
		updateChecker.start();
		
		
		
	}


	public void regCMD() {
		
		getCommand("simpletablist").setExecutor(new Commands(this));
		getCommand("simpletablist").setTabCompleter(new Commands(this));
		
	}

	public void Reg() {
		
		pm.registerEvents(this, this);
		pm.registerEvents(new TabList(this), this);
		pm.registerEvents(new TabListListeners(this),this);
		pm.registerEvents(new Animations(this),this);
		@SuppressWarnings("unused")
		Metrics metrics = new Metrics(this);

	}
	private void placeholders() {
		
		pchFile2 = new File(getDataFolder(), "placeholders.yml");
        if (!pchFile2.exists()) {
            getServer().getConsoleSender().sendMessage("�C[SimpleTablist] 'placeholders.yml' not found, creating one...");
            pchFile2.getParentFile().mkdirs();
            saveResource("placeholders.yml", false);
         }

        getPlaceholders= new YamlConfiguration();
        try {
            getPlaceholders.load(pchFile2);
        } catch (IOException | InvalidConfigurationException e) {
            e.printStackTrace();
        }
		
	}
	
	public void configAPI() {
		
		pchFile = new File(getDataFolder(), "animations.yml");
        if (!pchFile.exists()) {
            getServer().getConsoleSender().sendMessage("�C[SimpleTablist] 'animations.yml' not found, creating one...");
           pchFile.getParentFile().mkdirs();
            saveResource("animations.yml", false);
         }

        pchConfig= new YamlConfiguration();
        try {
            pchConfig.load(pchFile);
        } catch (IOException | InvalidConfigurationException e) {
            e.printStackTrace();
        }
		
	}

	Thread updateChecker = new Thread() {
	    @Override
	    public void run() {

	    	URL url = null;
	    	
	    	try {
	    	    url = new URL("https://api.spigotmc.org/legacy/update.php?resource=51166");
	    	} catch (MalformedURLException e) {
	    	    e.printStackTrace();
	    	}
	    	URLConnection conn = null;
	    	try {
	    	    conn = url.openConnection();
	    	} catch (IOException e) {
	    	    e.printStackTrace();
	    	}
	    	try {
	    	    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	    	    if (reader.readLine().equals("10.0.8")) {
	    	        System.out.println("[SimpleTablist] No updates available.");
	    	    } else {
	    	        Bukkit.getServer().getConsoleSender().sendMessage("�c[SimpleTablist] There is an update! Download it at https://www.spigotmc.org/resources/simpletablist-1-8-1-14-4-animated-header-footer.51166/");
	    	        
	    	    }
	    	} catch (IOException e) {
	    	    e.printStackTrace();
	    	}
	    	
	    }
	};
	@EventHandler
	public void onUpdate(PlayerJoinEvent e) {
		
		
		
	}
}
