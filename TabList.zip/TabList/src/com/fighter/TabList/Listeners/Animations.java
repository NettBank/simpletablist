package com.fighter.TabList.Listeners;

import java.util.ArrayList;
import org.bukkit.ChatColor;
import org.bukkit.event.Listener;
import com.fighter.TabList.Main;

public class Animations implements Listener {

	private static Main main;

	public Animations(Main main) {
		Animations.main=main;// TODO Auto-generated constructor stub
	}

	static int time;
	static ArrayList<String> messages;
	static String name;
	
	
	
	
	

	public static String placeholders(String pch3) {
		
		for(String pch: main.getPlaceholders.getConfigurationSection("Placeholders").getKeys(true)) {
			
			pch3 = pch3.replace(pch, ChatColor.translateAlternateColorCodes('&', main.getPlaceholders.getString("Placeholders."+pch)));
			
		}
		
		return pch3;
	}

	
	
}
