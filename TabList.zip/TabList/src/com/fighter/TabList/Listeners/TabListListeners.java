package com.fighter.TabList.Listeners;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Spliterator;
import java.util.concurrent.Callable;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.scheduler.BukkitTask;

import com.fighter.TabList.Main;
import com.fighter.TabList.API.API;
import com.fighter.TabList.API.Placeholders;
import com.fighter.TabList.API.TabList;
import com.fighter.tabPrefix.Prefix;

@SuppressWarnings("unused")
public class TabListListeners implements Listener {

	public static Main main;
	
	private static Method getHandleMethod;
    private static Field pingField;

	public static Plugin plugin;
	public static BukkitTask task;

	private static List<String> header;

	private static List<String> footer;

	private static int size1 = 0;

	private static int size2 = 0;
	private static boolean cancelled = false;
	
	public TabListListeners(Main main) {
		
		TabListListeners.main = main;
	}
	
	public static void tablistStart(Player p) 
	{
		header = new ArrayList<String>();
		footer = new ArrayList<String>();
		
		if(main.getConfig().contains("Tablist.Header")) {
			if(main.getConfig().getStringList("Tablist.Header") != null) {
				header = main.getConfig().getStringList("Tablist.Header");
			}
			else {
				main.getConfig().set("Tablist.Header", header);
				main.saveConfig();
			}
		}
		else {
			main.getConfig().set("Tablist.Header", header);
			main.saveConfig();
		}
		
		if(main.getConfig().contains("Tablist.Footer")) {
			if(main.getConfig().getStringList("Tablist.Footer") != null) {
				footer = main.getConfig().getStringList("Tablist.Footer");
			}
			else {
				main.getConfig().set("Tablist.Footer", footer);
				main.saveConfig();
			}
		}
		else {
			main.getConfig().set("Tablist.Footer", footer);
			main.saveConfig();
		}
		
		if(main.getConfig().contains("Tablist.UpdateTime")) {
			int interval = main.getConfig().getInt("Tablist.UpdateTime");
		}
		else {
			main.getConfig().set("Tablist.UpdateTime", 20);
			main.saveConfig();
		}
		
		size1 = header.size() - 1;
		size2 = footer.size() - 1;
		
		
		start(p);
	}
		
	
      
	public static void start(Player p) {
		
		int interval = main.getConfig().getInt("Tablist.UpdateTime");
		task = Bukkit.getScheduler().runTaskTimerAsynchronously(main, new Runnable() {
			
			
			int i1 = 0;
			int i2 = 0;
			
			@Override
			public void run() {
				
				for(Player p : Bukkit.getOnlinePlayers()) {
					
					
					try {
					
							
						TabList.sendTabTitle(p, (String)Placeholders.pch(header.get(i1), p), (String)Placeholders.pch(footer.get(i2), p));
					
						
							
							
						
					} catch (IllegalArgumentException
							                          | SecurityException e) {
					}
				}
				
				if(i1 < size1) {
					i1++;
				}
				else {
					i1 = 0;
				}
				
				if(i2 < size2) {
					i2++;
				}
				else {
					i2 = 0;
				}
			}
		}, 20 , interval);
		
		if(Bukkit.getOnlinePlayers().isEmpty() == true) {
			
			task.cancel();
		}
	}

	@EventHandler(priority = EventPriority.HIGHEST)
	public void onJoin(PlayerJoinEvent e) {
		
		Player p = e.getPlayer();
	
		if(isCancelled() == false) {
			
			tablistStart(p);
			cancelled = true;
			
		} else {
		
			task = null;
			cancelled = false;
		}
			
		
	}
	@EventHandler
	public void onleft(PlayerQuitEvent e) {
		
		Player p = e.getPlayer();
		if(isCancelled() == true) {
			
			
			
			unregTablist(p);
			cancelled = false;
			
		} else {
			
			task = null;
			cancelled = true;
		}
	}
	
	public static  void unregTablist(Player p) {
		
		task.cancel();
		cancelled = true;
		
	}
	public static boolean isCancelled() {
 
        return cancelled;
    }
	

	
	public static int getPing(Player player) {
        try {
            if (getHandleMethod == null) {
                getHandleMethod = player.getClass().getDeclaredMethod("getHandle");
                getHandleMethod.setAccessible(true);
            }
            Object entityPlayer = getHandleMethod.invoke(player);
            if (pingField == null) {
                pingField = entityPlayer.getClass().getDeclaredField("ping");
                pingField.setAccessible(true);
            }
            int ping = pingField.getInt(entityPlayer);

            return ping > 0 ? ping : 0;
        } catch (Exception e) {
            return 1;
        }
	}
	
	

}
