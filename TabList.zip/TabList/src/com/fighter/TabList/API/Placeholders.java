package com.fighter.TabList.API;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import com.fighter.TabList.Main;
import com.fighter.TabList.Listeners.Animations;
import me.clip.placeholderapi.PlaceholderAPI;


public class Placeholders {

	private static Method getHandleMethod;
    private static Field pingField;
	@SuppressWarnings("unused")
	private static Main main;
	
	
    public static Object pch(String pch, Player p) {
    	
		Runtime runtime = Runtime.getRuntime();   
		
		int online2 = Bukkit.getServer().getOnlinePlayers().size();
		String online = Integer.toString(online2);
		
		int ping2 = getPing(p);
		String ping = Integer.toString(ping2);
		
		int mb = 1024*1024;
		long freem = runtime.freeMemory() / mb;
		String freememory = Long.toString(freem);
		long memo = runtime.totalMemory() / mb ;
		String memory = Long.toString(memo);
		
		int online3 = Bukkit.getServer().getMaxPlayers();
		String maxonline = Integer.toString(online3);
		
		int onlinestaff = 0;
		
			for(Player staff2: Bukkit.getServer().getOnlinePlayers()) {
				
				if(staff2.hasPermission("simpletablist.staff")) {
					
					onlinestaff++;
					
			}
		}
			
			String staff = Integer.toString(onlinestaff);

		pch = ChatColor.translateAlternateColorCodes('&', pch); 
		pch = pch.replace("{ONLINE}", online);
		pch = pch.replace("{MAX-ONLINE}", maxonline);
		pch = pch.replace("{PLAYER-NAME}", p.getName());
		pch = pch.replace("{PLAYER-DISPLAYNAME}", p.getDisplayName());
		pch = pch.replace("{PLAYER-LISTNAME}", p.getPlayerListName());
		pch = pch.replace("{PING}", ping);
		pch = pch.replace("{STAFF-ONLINE}", staff);
		pch = pch.replace("{FREE-MEMORY}", freememory);
		pch = pch.replace("{MAX-MEMORY}", memory);
		pch = pch.replace("{GAMEMODE}", p.getGameMode().name());
		
		//pch = Animations.animations(pch);
		pch = Animations.placeholders(pch);
		
		if(API.setupEconomy() == false) {
		} else {
			
			final OfflinePlayer player = Bukkit.getOfflinePlayer(p.getUniqueId());
			double money = API.econ.getBalance(player);
			String balance = Double.toString(money);
			pch = pch.replace("{MONEY}", balance);
			
		}
		if(API.setupChat() == false) {
		} else {
			
			String pgroup = API.chat.getPrimaryGroup(p);
			pch = pch.replace("{GROUP}", pgroup);
		}
		
		if(API.papi == false) {
			
		} else {
			
			pch = PlaceholderAPI.setPlaceholders(p, pch);
		}
		
		
	

		
     return pch;
		
		
		
	}
    
	public static int getPing(Player player) {
        try {
            if (getHandleMethod == null) {
                getHandleMethod = player.getClass().getDeclaredMethod("getHandle");
                getHandleMethod.setAccessible(true);
            }
            Object entityPlayer = getHandleMethod.invoke(player);
            if (pingField == null) {
                pingField = entityPlayer.getClass().getDeclaredField("ping");
                pingField.setAccessible(true);
            }
            int ping = pingField.getInt(entityPlayer);

            return ping > 0 ? ping : 0;
        } catch (Exception e) {
            return 1;
        }
	}

}
