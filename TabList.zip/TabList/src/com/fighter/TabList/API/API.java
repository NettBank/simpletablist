package com.fighter.TabList.API;

import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

import com.fighter.TabList.Main;

import net.milkbowl.vault.chat.Chat;
import net.milkbowl.vault.economy.Economy;

public class API {
	
	public static boolean papi = false;
	public static boolean vault = false;
	public static Economy econ = null;
	public static Chat chat = null;
	
	public static void papi(Main main) {
		
		if(Bukkit.getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
			
			papi = true;
			
		} else {
			
			papi = false;
		}
		
	}

	public static boolean setupChat() {
		
		if(Bukkit.getServer().getPluginManager().getPlugin("Vault") == null) {
			
			return false;
		}
		
        RegisteredServiceProvider<Chat> chatProvider = Bukkit.getServer().getServicesManager().getRegistration(net.milkbowl.vault.chat.Chat.class);
        if (chatProvider == null) {
            return false;
        }
        chat = chatProvider.getProvider();
        return chat != null;
    }
	
	public static boolean setupEconomy() {
		
        if (Bukkit.getServer().getPluginManager().getPlugin("Vault") == null) {
        	
        	return false;
            
        }
        RegisteredServiceProvider<Economy> rsp = Bukkit.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        econ = rsp.getProvider();
        return econ != null;
    }



}
