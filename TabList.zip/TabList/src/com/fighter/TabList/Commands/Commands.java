package com.fighter.TabList.Commands;

import java.util.Collections;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.HandlerList;
import org.bukkit.util.StringUtil;

import com.fighter.TabList.Main;

public class Commands implements CommandExecutor, TabCompleter {

	private Main main;

	public Commands(Main main) {
		this.main=main;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String cmdlabel, String[] args) {
		
		if(args.length == 0) {

			List<String> msglist = main.getConfig().getStringList("Tablist.Commands.Usage");
			for(String msg: msglist ) {
			
			msg = ChatColor.translateAlternateColorCodes('&', msg);	
				
			sender.sendMessage(msg);
			
			}
			
		} else {
			
			if(args[0].equals("help")) {
				
				if(sender.hasPermission("simpletablist.help") || sender.hasPermission("simpletablist.*")) {
					
					List<String> msglist = main.getConfig().getStringList("Tablist.Commands.Help");
					for(String msg: msglist ) {
					
					msg = ChatColor.translateAlternateColorCodes('&', msg);	
						
					sender.sendMessage(msg);
					}
					
				} else {
					
					sender.sendMessage(ChatColor.translateAlternateColorCodes('&', main.getConfig().getString("Tablist.Commands.NoPermission")));
					
				}
				
			}
		  if(args[0].equals("reload")) {
			
			  if(sender.hasPermission("simpletablist.reload") || sender.hasPermission("simpletablist.*")) {
				  
				  List<String> msglist = main.getConfig().getStringList("Tablist.Commands.Reload");
					for(String msg: msglist ) {
					
					msg = ChatColor.translateAlternateColorCodes('&', msg);	
						
					sender.sendMessage(msg);
					main.reloadConfig();
					}
					
				  
			  } else {
				  
				  sender.sendMessage(ChatColor.translateAlternateColorCodes('&', main.getConfig().getString("Tablist.Commands.NoPermission")));
				  
			  }
			  
		  }
		  if(args[0].equals("disable")) {
				
			  if(sender.hasPermission("simpletablist.disable") || sender.hasPermission("simpletablist.*")) {
				  
				  List<String> msglist = main.getConfig().getStringList("Tablist.Commands.Disable");
					for(String msg: msglist ) {
					
					msg = ChatColor.translateAlternateColorCodes('&', msg);	
						
					sender.sendMessage(msg);
					Bukkit.getPluginManager().disablePlugin(main);
					HandlerList.unregisterAll();
					
					}
				  
			  } else {
				  
				  sender.sendMessage(ChatColor.translateAlternateColorCodes('&', main.getConfig().getString("Tablist.Commands.NoPermission")));
				  
			  }
			  
		  }
		  if(args[0].equals("about")) {
				
			  if(sender.hasPermission("simpletablist.about") || sender.hasPermission("simpletablist.*")) {
				  
				  List<String> msglist = main.getConfig().getStringList("Tablist.Commands.About");
					for(String msg: msglist ) {
					
					msg = ChatColor.translateAlternateColorCodes('&', msg);	
						
					sender.sendMessage(msg);
					}
				  
			  } else {
				  
				  sender.sendMessage(ChatColor.translateAlternateColorCodes('&', main.getConfig().getString("Tablist.Commands.NoPermission")));
				  
			  }
			  
		  }
		  
		  
			
		}
		
		return false;
	}

	@Override
	public List<String> onTabComplete(CommandSender sender, Command cmd, String cmdlabel, String[] args) {
	
		List<String> completionList = new java.util.ArrayList<>();
		if (cmd.getName().equalsIgnoreCase("simpletablist") || cmd.getName().equalsIgnoreCase("st") && args.length < 2) {
			List<String> cmds = new java.util.ArrayList<>();
			for (String com : getCmds(sender)) {
				cmds.add(com);
			}
			StringUtil.copyPartialMatches(args[0], cmds, completionList);
		}
		Collections.sort(completionList);
		return completionList;
	}
	private List<String> getCmds(CommandSender sender) {
		List<String> c = new java.util.ArrayList<>();
		for (String cmds : new String[] { "help", "reload", "disable", "about" }) {
			if (!sender.hasPermission(main.getConfig().getString("Tablist.Commands.TabCompletePermission") + cmds))
				continue;
			c.add(cmds);
		}
		return c;
	}
		
		

}
