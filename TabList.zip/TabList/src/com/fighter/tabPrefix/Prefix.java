package com.fighter.tabPrefix;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitScheduler;

import com.fighter.TabList.Main;
import com.fighter.TabList.API.API;
import com.fighter.TabList.API.Placeholders;

public class Prefix {

	public static void tabPrefix(Player p, Main main) {
		
		if(API.setupChat() == false || API.setupEconomy() == false) {
			
		} else {
		
			BukkitScheduler scheduler = Bukkit.getServer().getScheduler();
	    	scheduler.scheduleSyncRepeatingTask(main, new Runnable() {
	    		
	    		
	    		
	    		public void run() {
	    		
	    			for(Player p: Bukkit.getOnlinePlayers()) {
	        			
	    				for(String group: main.getConfig().getConfigurationSection("TablistPrefix").getKeys(true)) {
	        				
	        				if(main.getConfig().getBoolean("TablistPrefix."+group+".enable")) {
	        				
	        				if(API.chat.getPrimaryGroup(p).equals(main.getConfig().getString("TablistPrefix."+group+".group"))) {
	      
	        					
	        						p.setPlayerListName((String) Placeholders.pch(main.getConfig().getString("TablistPrefix."+group+".prefix"), p));
	        				}
	        				
	        			}
	        			
	        		 }
	    			}
	    		}
	    			
	    	}, 0, 20L);
		}
		
		
	}

}
